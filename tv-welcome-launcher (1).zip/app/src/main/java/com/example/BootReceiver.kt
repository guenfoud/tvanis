package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d("BootReceiver", "Received broadcast action: $action")
        
        if (action == Intent.ACTION_BOOT_COMPLETED || 
            action == "android.intent.action.QUICKBOOT_POWERON" || 
            action == "com.htc.intent.action.QUICKBOOT_POWERON") {
            
            // Read from SharedPreferences to check if autostart is enabled
            val prefs = context.getSharedPreferences("tv_settings", Context.MODE_PRIVATE)
            val launchOnBoot = prefs.getBoolean("launch_on_boot", true)
            
            if (launchOnBoot) {
                Log.d("BootReceiver", "Starting MainActivity from boot completion...")
                try {
                    val activityIntent = Intent(context, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                    context.startActivity(activityIntent)
                } catch (e: Exception) {
                    Log.e("BootReceiver", "Failed to start MainActivity", e)
                }
            } else {
                Log.d("BootReceiver", "Launch on boot is disabled in settings.")
            }
        }
    }
}
