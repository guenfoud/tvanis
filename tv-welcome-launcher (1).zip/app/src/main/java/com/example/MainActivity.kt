package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    // Callback to toggle settings screen when Menu or Settings buttons are pressed on the TV remote
    var onMenuPressed: (() -> Unit)? = null
    private var webViewInstance: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Read keep screen on preference
        val prefs = getSharedPreferences("tv_settings", Context.MODE_PRIVATE)
        val keepScreenOn = prefs.getBoolean("keep_screen_on", true)
        if (keepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TVWelcomeScreen(
                        activity = this,
                        onWebViewCreated = { webViewInstance = it }
                    )
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Intercept MENU or SETTINGS key on standard TV remote control
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_SETTINGS) {
            onMenuPressed?.invoke()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    fun updateKeepScreenOn(enabled: Boolean) {
        runOnUiThread {
            if (enabled) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TVWelcomeScreen(
    activity: MainActivity,
    onWebViewCreated: (WebView) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tv_settings", Context.MODE_PRIVATE) }

    // Load initial settings
    var baseUrl by remember { mutableStateOf(prefs.getString("base_url", "http://192.168.20.9:3000/tv-welcome") ?: "http://192.168.20.9:3000/tv-welcome") }
    var roomNumber by remember { mutableStateOf(prefs.getString("room_number", "101") ?: "101") }
    var launchOnBoot by remember { mutableStateOf(prefs.getBoolean("launch_on_boot", true)) }
    var keepScreenOn by remember { mutableStateOf(prefs.getBoolean("keep_screen_on", true)) }
    var zoomLevel by remember { mutableStateOf(prefs.getInt("zoom_level", 100)) }

    var showSettings by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var keyTriggerReload by remember { mutableStateOf(0) } // Used to trigger webview reload when settings change

    var webView: WebView? by remember { mutableStateOf(null) }

    // Register callback in the activity to toggle settings
    LaunchedEffect(Unit) {
        activity.onMenuPressed = {
            showSettings = !showSettings
        }
    }

    // Full URL helper
    val fullUrl = remember(baseUrl, roomNumber, keyTriggerReload) {
        val trimmedBase = baseUrl.trim()
        val separator = if (trimmedBase.contains("?")) "&" else "?"
        "$trimmedBase${separator}room=${roomNumber.trim()}"
    }

    // Back button handling on Android TV
    BackHandler(enabled = true) {
        if (showSettings) {
            showSettings = false
        } else if (webView?.canGoBack() == true) {
            webView?.goBack()
        } else {
            // If we are showing the WebView and cannot go back in history,
            // pressing Back will open settings. This makes sure the user is never stuck.
            showSettings = true
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (loadError != null) {
            // Elegant error state screen (useful if local welcome server is offline)
            ErrorScreen(
                errorMsg = loadError ?: "",
                targetUrl = fullUrl,
                onRetry = {
                    loadError = null
                    webView?.loadUrl(fullUrl)
                },
                onOpenSettings = {
                    showSettings = true
                }
            )
        } else {
            // The Main WebView Container
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        onWebViewCreated(this)
                        webView = this
                        
                        // Critical WebView Configurations for smooth web rendering
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.databaseEnabled = true
                        settings.loadWithOverviewMode = true
                        settings.useWideViewPort = true
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW // Critical for HTTP URLs
                        
                        // Prevent cache issues for welcome display
                        settings.cacheMode = WebSettings.LOAD_DEFAULT

                        webViewClient = object : WebViewClient() {
                            override fun onReceivedError(
                                view: WebView?,
                                request: WebResourceRequest?,
                                error: WebResourceError?
                            ) {
                                super.onReceivedError(view, request, error)
                                if (request?.isForMainFrame == true) {
                                    val description = error?.description?.toString() ?: "Connection Refused"
                                    loadError = "Could not connect to Welcome Server.\n\nReason: $description"
                                }
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                if (loadError == null) {
                                    // Successfully loaded
                                }
                            }
                        }

                        // Apply text zoom
                        setInitialZoomAndScale(this, zoomLevel)

                        loadUrl(fullUrl)
                    }
                },
                update = { view ->
                    // Apply updated settings dynamically
                    view.settings.textZoom = zoomLevel
                    onWebViewCreated(view)
                    webView = view
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Small, semi-transparent Settings FAB in the top-right corner.
        // On TV, it can be focused with the D-pad remote buttons.
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(24.dp)
        ) {
            var isFabFocused by remember { mutableStateOf(false) }
            IconButton(
                onClick = { showSettings = true },
                modifier = Modifier
                    .size(48.dp)
                    .alpha(if (isFabFocused) 1.0f else 0.4f)
                    .onFocusChanged { isFabFocused = it.isFocused }
                    .background(
                        color = if (isFabFocused) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .border(
                        width = 2.dp,
                        color = if (isFabFocused) Color.White else Color.Transparent,
                        shape = RoundedCornerShape(24.dp)
                    )
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Open Settings",
                    tint = Color.White
                )
            }
        }

        // Settings Dialog Modal
        if (showSettings) {
            SettingsDialog(
                currentBaseUrl = baseUrl,
                currentRoomNumber = roomNumber,
                currentLaunchOnBoot = launchOnBoot,
                currentKeepScreenOn = keepScreenOn,
                currentZoomLevel = zoomLevel,
                onDismiss = { showSettings = false },
                onSave = { newUrl, newRoom, newBoot, newKeep, newZoom ->
                    baseUrl = newUrl
                    roomNumber = newRoom
                    launchOnBoot = newBoot
                    keepScreenOn = newKeep
                    zoomLevel = newZoom

                    // Save to SharedPreferences
                    prefs.edit().apply {
                        putString("base_url", newUrl)
                        putString("room_number", newRoom)
                        putBoolean("launch_on_boot", newBoot)
                        putBoolean("keep_screen_on", newKeep)
                        putInt("zoom_level", newZoom)
                        apply()
                    }

                    // Update screen keep-awake state
                    activity.updateKeepScreenOn(newKeep)

                    // Refresh WebView
                    loadError = null
                    keyTriggerReload++
                    webView?.settings?.textZoom = newZoom
                    webView?.loadUrl(fullUrl)

                    showSettings = false
                }
            )
        }
    }
}

private fun setInitialZoomAndScale(webView: WebView, zoomLevel: Int) {
    webView.settings.textZoom = zoomLevel
}

@Composable
fun ErrorScreen(
    errorMsg: String,
    targetUrl: String,
    onRetry: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121214))
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = "Error Warning",
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(72.dp)
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Welcome Screen Offline",
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "Target URL: $targetUrl",
            color = Color.Gray,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E22)),
            modifier = Modifier
                .widthIn(max = 600.dp)
                .padding(horizontal = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = errorMsg,
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Text(
                    text = "Troubleshooting Tips:\n1. Ensure the web server at 192.168.20.9 is running on port 3000.\n2. Confirm this TV is on the exact same local Wi-Fi or Ethernet network.\n3. Make sure the room number configuration is correct.",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.wrapContentSize()
        ) {
            var isRetryFocused by remember { mutableStateOf(false) }
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRetryFocused) MaterialTheme.colorScheme.primary else Color(0xFF2E2E34)
                ),
                modifier = Modifier
                    .onFocusChanged { isRetryFocused = it.isFocused }
                    .border(
                        width = 2.dp,
                        color = if (isRetryFocused) Color.White else Color.Transparent,
                        shape = RoundedCornerShape(8.dp)
                    )
            ) {
                Text("Retry Connection", color = Color.White, fontSize = 16.sp)
            }

            var isSettingsFocused by remember { mutableStateOf(false) }
            Button(
                onClick = onOpenSettings,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSettingsFocused) MaterialTheme.colorScheme.secondary else Color(0xFF2E2E34)
                ),
                modifier = Modifier
                    .onFocusChanged { isSettingsFocused = it.isFocused }
                    .border(
                        width = 2.dp,
                        color = if (isSettingsFocused) Color.White else Color.Transparent,
                        shape = RoundedCornerShape(8.dp)
                    )
            ) {
                Text("Configure App", color = Color.White, fontSize = 16.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDialog(
    currentBaseUrl: String,
    currentRoomNumber: String,
    currentLaunchOnBoot: Boolean,
    currentKeepScreenOn: Boolean,
    currentZoomLevel: Int,
    onDismiss: () -> Unit,
    onSave: (baseUrl: String, roomNumber: String, launchOnBoot: Boolean, keepScreenOn: Boolean, zoomLevel: Int) -> Unit
) {
    var baseUrlInput by remember { mutableStateOf(currentBaseUrl) }
    var roomNumberInput by remember { mutableStateOf(currentRoomNumber) }
    var launchOnBootVal by remember { mutableStateOf(currentLaunchOnBoot) }
    var keepScreenOnVal by remember { mutableStateOf(currentKeepScreenOn) }
    var zoomLevelVal by remember { mutableStateOf(currentZoomLevel) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(16.dp))
                .border(2.dp, Color(0xFF3E3E42), RoundedCornerShape(16.dp)),
            color = Color(0xFF1E1E22)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Text(
                    text = "TV Welcome Launcher - Settings",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                
                Divider(color = Color(0xFF3E3E42), thickness = 1.dp, modifier = Modifier.padding(bottom = 16.dp))

                // Base URL
                Text(
                    text = "Welcome Page Server URL:",
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                
                var isUrlFocused by remember { mutableStateOf(false) }
                OutlinedTextField(
                    value = baseUrlInput,
                    onValueChange = { baseUrlInput = it },
                    singleLine = true,
                    placeholder = { Text("http://192.168.20.9:3000/tv-welcome", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color.Gray,
                        focusedContainerColor = Color(0xFF121214),
                        unfocusedContainerColor = Color(0xFF121214)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .onFocusChanged { isUrlFocused = it.isFocused }
                        .border(
                            width = if (isUrlFocused) 2.dp else 0.dp,
                            color = if (isUrlFocused) Color.White else Color.Transparent,
                            shape = RoundedCornerShape(4.dp)
                        )
                )
                
                Spacer(modifier = Modifier.height(12.dp))

                // Room Number
                Text(
                    text = "This TV's Room Number:",
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                
                var isRoomFocused by remember { mutableStateOf(false) }
                OutlinedTextField(
                    value = roomNumberInput,
                    onValueChange = { roomNumberInput = it },
                    singleLine = true,
                    placeholder = { Text("101", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color.Gray,
                        focusedContainerColor = Color(0xFF121214),
                        unfocusedContainerColor = Color(0xFF121214)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .onFocusChanged { isRoomFocused = it.isFocused }
                        .border(
                            width = if (isRoomFocused) 2.dp else 0.dp,
                            color = if (isRoomFocused) Color.White else Color.Transparent,
                            shape = RoundedCornerShape(4.dp)
                        )
                )
                
                Spacer(modifier = Modifier.height(16.dp))

                // WebView Zoom Adjustment (critical for different TV resolutions)
                Text(
                    text = "WebView Scaling / Zoom Level: $zoomLevelVal%",
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    var isDecFocused by remember { mutableStateOf(false) }
                    Button(
                        onClick = { if (zoomLevelVal > 30) zoomLevelVal -= 10 },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E2E34)),
                        modifier = Modifier
                            .onFocusChanged { isDecFocused = it.isFocused }
                            .border(
                                width = 2.dp,
                                color = if (isDecFocused) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                    ) {
                        Text("- Decrease", color = Color.White)
                    }

                    var isIncFocused by remember { mutableStateOf(false) }
                    Button(
                        onClick = { if (zoomLevelVal < 300) zoomLevelVal += 10 },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E2E34)),
                        modifier = Modifier
                            .onFocusChanged { isIncFocused = it.isFocused }
                            .border(
                                width = 2.dp,
                                color = if (isIncFocused) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                    ) {
                        Text("+ Increase", color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Toggles
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    var isBootFocused by remember { mutableStateOf(false) }
                    Checkbox(
                        checked = launchOnBootVal,
                        onCheckedChange = { launchOnBootVal = it },
                        colors = CheckboxDefaults.colors(
                            checkedColor = MaterialTheme.colorScheme.primary,
                            uncheckedColor = Color.Gray,
                            checkmarkColor = Color.White
                        ),
                        modifier = Modifier
                            .onFocusChanged { isBootFocused = it.isFocused }
                            .border(
                                width = 2.dp,
                                color = if (isBootFocused) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(4.dp)
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Launch automatically on TV Boot / Startup", color = Color.White, fontSize = 14.sp)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    var isKeepFocused by remember { mutableStateOf(false) }
                    Checkbox(
                        checked = keepScreenOnVal,
                        onCheckedChange = { keepScreenOnVal = it },
                        colors = CheckboxDefaults.colors(
                            checkedColor = MaterialTheme.colorScheme.primary,
                            uncheckedColor = Color.Gray,
                            checkmarkColor = Color.White
                        ),
                        modifier = Modifier
                            .onFocusChanged { isKeepFocused = it.isFocused }
                            .border(
                                width = 2.dp,
                                color = if (isKeepFocused) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(4.dp)
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Keep Screen Awake (Prevent TV from sleeping)", color = Color.White, fontSize = 14.sp)
                }

                Spacer(modifier = Modifier.weight(1.0f))
                Spacer(modifier = Modifier.height(24.dp))

                // Footer Buttons
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    var isCancelFocused by remember { mutableStateOf(false) }
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .onFocusChanged { isCancelFocused = it.isFocused }
                            .border(
                                width = 2.dp,
                                color = if (isCancelFocused) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 8.dp)
                    ) {
                        Text("Cancel", color = Color.Gray, fontSize = 16.sp)
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    var isSaveFocused by remember { mutableStateOf(false) }
                    Button(
                        onClick = {
                            onSave(baseUrlInput, roomNumberInput, launchOnBootVal, keepScreenOnVal, zoomLevelVal)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .onFocusChanged { isSaveFocused = it.isFocused }
                            .border(
                                width = 2.dp,
                                color = if (isSaveFocused) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                    ) {
                        Text("Save & Apply", color = Color.White, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
